# Simulador de semáforo con HTML-CSS-JAVASCRIPT 
### Video del tutorial: [https://youtu.be/3Kpx3mq-FYI](https://youtu.be/3Kpx3mq-FYI)
![semafor1](https://user-images.githubusercontent.com/85034795/130899097-20c360c3-216d-4a56-8d13-89bafde74857.png)
